#include <iostream>
#include<chrono>
#include<fstream>
#include<iomanip>
#include "String.h"
using namespace std;

const int QUINTET = 5;

void swap(double* x, double* y)
{
	double temp = *x;
	*x = *y;
	*y = temp;

}

void bubbleSort(double* arr, int size)
{
	int i, j;

	for (i = 0; i < size - 1; i++)
		for (j = 0; j < size - i - 1; j++)
		{
			if (arr[j] > arr[j + 1])
			{
				swap(arr[j], arr[j + 1]);
			}
		}
}

void errorMsg()
{
	cout << "wrong input" << endl;
	exit(1);
}
void swap(double& i, double& j)
{
	double temp = i;
	i = j;
	j = temp;
}

void insertionSort(double *arr, int size)
{
	int i = 0;
	int j = 0;
	for (i; i < size; i++)
	{
		j = i;
		while (j > 0 && arr[j - 1] > arr[j])
		{
			swap(arr[j], arr[j - 1]);
			j--;
		}

	}
}

///////////////////////////////////////////////////

int partition(double* arr, int start, int size)
{
	int pivot, i, temp;
	pivot = start;
	i = size;//size-1

	while (i != pivot)
	{
		if (i < pivot)
		{
			if (arr[i] < arr[pivot])
				i++;
			else
			{
				swap(arr[i], arr[pivot]);
				temp = i;
				i = pivot;
				pivot = temp;
				i--;
			}
		}
		else
		{
			if (arr[pivot] < arr[i])
				i--;
			else
			{
				swap(arr[i], arr[pivot]);
				temp = i;
				i = pivot;
				pivot = temp;
				i++;
				
			}
		}
	}
	return pivot;
}

int partition2(double* arr, int left,int right, double& pivot)
{
	int i;
	//double v_pivot = *pivot;

	for (i = 0; i < right; i++)
		if (arr[i] == pivot)
			break;

	swap(arr[i], arr[0]);
	
	while (left <= right)
	{
		if (arr[left] > pivot && arr[right] <pivot)
			swap(arr[left], arr[right]);
		else
		{
			
			while (arr[right] > pivot)
				right--;
			while(arr[left] < pivot )
				left++;
		}
	}

	swap(arr[right], arr[0]);

	return right;
}

double select(double* arr, int left, int right, int i)
{
	int pivot, leftPart;

	pivot = partition(arr, left, right);
	//pivot = partition2(arr, left, right, arr[0]);
	leftPart = pivot - left + 1;
	if (i == leftPart)
		return arr[pivot];
	if (i < leftPart)
		return select(arr, left, pivot-1, i);
	else
		return select(arr, pivot+1, right, i - leftPart);
}

double& quintetsSort(double* arr, int size, int idx)
{
	int i, j,  mediansIdx = 0, lastQuintetSize = size % 5;
	int quintetSize = 5;
	int numOfQuintets = ceil((double)size / 5);
	bool isLastQuintet = false;
	bool isDividedByFive = size % 5 == 0;
	int k;
	
	if (size <= 5)
	{
		bubbleSort(arr, size);
		return arr[idx-1];
	}
	double tempArr[QUINTET]{ 0 };
	double* B= new double[numOfQuintets];

	for (i = 0; i < numOfQuintets; i++)
	{
		if (i == numOfQuintets -1 )
		{
			isLastQuintet = true;
			if(lastQuintetSize != 0)
				quintetSize = lastQuintetSize;
		}
		for (j = 0; j < quintetSize; j++)
		{
			tempArr[j] = arr[j+(i*QUINTET)];
		}
		bubbleSort(tempArr, QUINTET);
		if(isLastQuintet == true && !isDividedByFive)
			B[mediansIdx] = tempArr[lastQuintetSize / 2];
		else if(isLastQuintet == true)
			B[mediansIdx] = tempArr[quintetSize / 2];
		else
		{
			B[mediansIdx] = tempArr[quintetSize / 2];
			mediansIdx++;
		}
	}
	//double pivot = select(B, 0, mediansSize, (mediansSize / 2)+1);// the median is the the member which the n/2+1 in size

	double pivot = quintetsSort(B, numOfQuintets, numOfQuintets / 2);

	k = partition2(arr, 1, size-1, pivot);
	
	if (idx < k)
	{
		if (k - 1 == 9)
		{
			cout << "pivot = " << pivot << endl;
			cout << " k = " << k << endl;
			for (int index = 0; index < k-1; index++)
				cout << arr[index] << " , ";
		}
		return quintetsSort(arr, k, idx);
	}
	if (idx > k)
	{
		return quintetsSort(arr + k+1, size-k-1, idx - k-1);
	}
	return arr[k];
}






int main()
{
	int n, i, j, counter, idx;
	double temp;
	char ch;

	cout << "Please enter the number of numbers you would like to enter and after that," <<
		" enter the index you would like to find" << endl;
	cin >> n >> i;

	cout << "Please enter the numbers from which you would like to find the index" << endl;
	

	double *arr = new double[n];
	
	counter = idx = 0;
	for(idx = 0; idx < n; idx++)
	{
		String str;
		if (idx == 500)
			idx = idx;
		str.getNum();
		arr[idx] = atof(str);
	}
	cout << endl;

	double* CopyArr = new double[n];
	for (idx = 0; idx < n; idx++)
	{
		CopyArr[idx] = arr[idx];
	}

	double* CopyArr2 = new double[n];
	for (idx = 0; idx < n; idx++)
	{
		CopyArr2[idx] = arr[idx];
	}

	cout << endl;
	
	auto start = chrono::high_resolution_clock::now();
	// unsync the I/O of C and C++.
	ios_base::sync_with_stdio(false);
	insertionSort(arr, n);// Here you put the name of the function you wish to measure
	auto end = chrono::high_resolution_clock::now();

	// Calculating total time taken by the program.
	double time_taken =
		chrono::duration_cast<chrono::nanoseconds>(end - start).count();
	time_taken *= 1e-9;
	ofstream myfile("Measure.txt", ios::app); // The name of the file
	myfile << "Time taken by function <name-of-fun> is : " << fixed
		<< time_taken << setprecision(9);
	myfile << " sec" << endl;
	myfile.close();

	/*for (idx = 0; idx < n; idx++)
	{
		cout << arr[idx] << endl;
	}*/
	cout << endl;

	cout<<fixed<< setprecision(4) << arr[i-1] << endl;

//	cout << selection(arr,n, i) << endl;

	cout << fixed << setprecision(4)<< select(CopyArr, 0, n, i) << endl;

	auto start2 = chrono::high_resolution_clock::now();
	// unsync the I/O of C and C++.
	ios_base::sync_with_stdio(false);
// Here you put the name of the function you wish to measure
	select(arr, 0, n, i);
	auto end2 = chrono::high_resolution_clock::now();
	
		// Calculating total time taken by the program.
		double time_taken2 =
		chrono::duration_cast<chrono::nanoseconds>(end2 - start2).count();
	time_taken2 *= 1e-9;
	ofstream myfile2("Measure.txt",ios::app); // The name of the file
	myfile2 << "Time taken by function <name-of-fun> is : " << fixed
		<< time_taken2 << setprecision(9);
	myfile2 << " sec" << endl;
	myfile2.close();



	double test = quintetsSort(CopyArr2, n, i);
	cout << "---------------" << endl;
	cout << test << endl;

	return 0;
}
//
//int main()
//{
//	double num;
//	double arr[] = { -154.1693, -362.807, 334.1388, 16.306, 5.0423, 27.3922, -225.2371, 45.602, -28.9284, 152.1698 };
//	num = select(arr, 0, 9, 8);
//	cout << num << endl;
//	insertionSort(arr, 10);
//	cout << arr[7];
//	return 0;
//}

